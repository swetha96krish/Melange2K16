package srm.easwari.pin;

public class Config {
    public static final String DEVELOPER_KEY = "AIzaSyBJ-pMi57fV8kCX38-QYs083i7g9vJ5shQ";

    // YouTube video id
    public static final String YOUTUBE_VIDEO_CODE = "_oEA18Y8gM0";
    public static final String YT_K="HlxGaxhTmao";
}


