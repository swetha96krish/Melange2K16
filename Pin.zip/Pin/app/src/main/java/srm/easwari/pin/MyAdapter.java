package srm.easwari.pin;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by LENOVO on 2/24/2016.
 */
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    private ArrayList<details> det;

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public View view;

        public ViewHolder(View v) {
            super(v);
            view = v;
        }
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyAdapter(ArrayList<details> det) {
        this.det = det;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card, parent, false);
        // set the view's size, margins, paddings and layout parameters

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        CardView cv = (CardView) holder.view.findViewById(R.id.cv);

        TextView tv = (TextView) holder.view.findViewById(R.id.txt);
        ImageView im = (ImageView) holder.view.findViewById(R.id.img);
        tv.setText(det.get(position).getNames());
        im.setImageResource(det.get(position).getImgid());
        cv.setShadowPadding(5, 5, 5, 5);
        cv.setCardElevation(10);
        cv.setRadius(100);
        cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "" + det.get(position).getNames(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+det.get(position).getPhno()));
                v.getContext().startActivity(i);
            }
        });
    }



    @Override
    public int getItemCount() {
        return det.size();
    }
}