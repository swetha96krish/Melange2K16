package srm.easwari.pin;

public class PinnacleEvents {
    public int id;
    public String title,rules;
    public int nor,nop;
}
