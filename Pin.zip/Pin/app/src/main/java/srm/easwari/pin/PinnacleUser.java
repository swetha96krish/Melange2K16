package srm.easwari.pin;

public class PinnacleUser {
    public String fname,lname;
    public String year;
    public String dept,college,phno,mail;
}
