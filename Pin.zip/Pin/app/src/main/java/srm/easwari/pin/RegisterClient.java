package srm.easwari.pin;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class RegisterClient extends AsyncTask<PinnacleUser, Void, String> {
    private final String TAG = "register";
    private ProgressDialog  progress;
    private Context c;
    public RegisterClient(Context c) {
        this.c=c;
        progress = new ProgressDialog(c);
    }

   @Override
    protected void onPreExecute() {
        progress.setMessage("your registration is in progress");
        progress.setProgress(ProgressDialog.STYLE_SPINNER);
        progress.show();

    }

    @Override
    protected String doInBackground(PinnacleUser... params ){
        try {
            PinnacleUser u = params[0];
            String link = "http://10.0.2.2:8080/pinnacle2k16/rest/service/register";
            Gson g=new Gson();
            String json=g.toJson(u);
            Log.e(TAG, "json:" + json);

            try {
                URL url = new URL(link);
                HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoInput(true);
                connection.setDoOutput(true);
                connection.connect();
                PrintWriter wr = new PrintWriter(connection.getOutputStream());
                wr.write(json);
                wr.flush();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String result = new String();
                String st;
                while ((st = bufferedReader.readLine()) != null) {
                    result += st;
                }

                return ""+connection.getResponseCode();
            } catch (MalformedURLException e) {
                Log.e(TAG, "Exception: " + e.getMessage());
                return null;
            }} catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
            Log.e(TAG, String.valueOf(e.getStackTrace()));
            return null;
        }
    }
    @Override
    protected void onPostExecute(String res){
        super.onPostExecute(res);
        progress.dismiss();

        if((res!=null)&&res.charAt(0)=='2')
        Toast.makeText(c, "successful registration", Toast.LENGTH_SHORT).show();
     else
        {
            if((res!=null)&&res.charAt(0)=='5')
                Toast.makeText(c, "unsuccessful registration.try again", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(c, "check your connectivity", Toast.LENGTH_SHORT).show();
        }
    }
}

