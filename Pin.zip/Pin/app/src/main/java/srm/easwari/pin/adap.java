package srm.easwari.pin;

/**
 * Created by LENOVO on 2/26/2016.
 */
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by LENOVO on 2/24/2016.
 */
public class adap extends RecyclerView.Adapter<adap.ViewHolder> {
    private ArrayList<id> id;

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public View view;

        public ViewHolder(View v) {
            super(v);
            view = v;
        }
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public adap(ArrayList<id> id) {
        this.id=id;

    }

    // Create new views (invoked by the layout manager)
    @Override
    public adap.ViewHolder onCreateViewHolder(ViewGroup parent,int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.events, parent, false);
        // set the view's size, margins, paddings and layout parameters

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        CardView cv = (CardView) holder.view.findViewById(R.id.cv);
        //cv.setBackgroundColor(Color.rgb(255, 255, 255));
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            // below lillipop
            cv.setCardBackgroundColor(Color.WHITE);
            // working for lower questions as per another answer posted here
        } else {
            // lollipop and above
            cv.setBackgroundColor(Color.WHITE);
            // known to be working for lillipop as per your question
        }
        cv.setBackgroundResource(id.get(position).getImgid());
        cv.setShadowPadding(5, 5, 5, 5);
        cv.setCardElevation(10);
        cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),eventdeta.class);
                intent.putExtra("bg",id.get(position).getBgid());
                intent.putExtra("id",id.get(position).getEve());
                intent.putExtra("mem",id.get(position).getMembers());
                intent.putExtra("desc",id.get(position).getDesc());
                intent.putExtra("rules",id.get(position).getRules());
                intent.putExtra("rounds",id.get(position).getRounds());
                v.getContext().startActivity(intent);


            }
        });

    }



    @Override
    public int getItemCount() {
        return id.size();
    }
}