package srm.easwari.pin;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class contact extends Fragment{

        ListView list;
        String[] names = {
            "president",
            "vicepresident",
            "secretary",
            "treasurer",
            "editor"
    } ;
        Integer[] imageId = {
                R.drawable.eec,
                R.drawable.quizb,
                R.drawable.quizicon,
                R.drawable.treasurehunt,
                R.drawable.treasuremap
        };
    String[] phone = {
            "tel:9999999999",
            "tel:8888888888",
            "tel:7575454554",
            "tel:1236547896",
            "tel:9984519575"
    };

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_contacts, container, false);
        addListenerOnButton(rootView);
        return rootView;
    }
    public void addListenerOnButton(View v) {
            custom adapter = new custom(getActivity(), names, imageId);
            list=(ListView) v.findViewById(R.id.all_events);
            list.setAdapter(adapter);
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {
                    Toast.makeText(getActivity(), "" + names[+position], Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse(phone[+position]));
                    startActivity(i);
                }
            });

        }

        }



