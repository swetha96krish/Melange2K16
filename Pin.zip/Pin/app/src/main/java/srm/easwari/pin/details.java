package srm.easwari.pin;

/**
 * Created by LENOVO on 2/24/2016.
 */
public class details {
    String names;
    int imgid;
    String phno;
    public details(String names,int imgid,String phno)
    {
      this.names=names;
        this.imgid=imgid;
        this.phno=phno;
    }

    public int getImgid() {
        return imgid;
    }

    public String getNames() {
        return names;
    }

    public String getPhno() {
        return phno;
    }
}
