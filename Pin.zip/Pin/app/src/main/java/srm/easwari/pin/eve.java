package srm.easwari.pin;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by LENOVO on 3/3/2016.
 */
public class eve extends Fragment {
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.eve, container, false);

        addListenerOnButton(rootView);
        return rootView;
    }
    public void addListenerOnButton(View v) {
        ImageButton  img=(ImageButton)v.findViewById(R.id.imageButton);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(v.getContext(),eventdeta.class);
                v.getContext().startActivity(in);
            }
        });
    }

    }
