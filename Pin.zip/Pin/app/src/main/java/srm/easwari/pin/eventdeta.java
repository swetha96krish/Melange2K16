package srm.easwari.pin;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


public class eventdeta extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.eventdeta);
        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.mapButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent id = new Intent(eventdeta.this,web.class);
                id.putExtra("url","http://192.168.0.102:8080/finals");
                startActivity(id);

            }
        });
        Intent intent=getIntent();
        int id=intent.getIntExtra("bg", 0);
        String titles=intent.getStringExtra("id");
        TextView title=(TextView)findViewById(R.id.TITLE);
        title.setText(titles);
        String nop=intent.getStringExtra("mem");
        TextView p=(TextView)findViewById(R.id.NOP);
        p.setText(nop);
        String desc=intent.getStringExtra("desc");
        TextView de=(TextView)findViewById(R.id.DESC);
        de.setText(desc);
        String rules=intent.getStringExtra("rules");
        TextView rule=(TextView)findViewById(R.id.RULES);
        rule.setText(rules);
        String nor=intent.getStringExtra("rounds");
        TextView norr=(TextView)findViewById(R.id.NOR);
        norr.setText(nor);
        LinearLayout l=(LinearLayout)findViewById(R.id.ed);

        l.setBackground(getResources().getDrawable(id, getTheme()));

    }
}