package srm.easwari.pin;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Created by LENOVO on 2/24/2016.
 */
public class events extends Fragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.rec, container, false);
        addListenerOnButton(rootView);
        return rootView;
    }
    public void addListenerOnButton(View root){
        mRecyclerView = (RecyclerView) root.findViewById(R.id.rv);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        mRecyclerView.setHasFixedSize(true);

        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(root.getContext());
        mRecyclerView.setLayoutManager(mLayoutManager);

        // specify an adapter (see also next example)
        ArrayList<id> arr=new ArrayList<id>();
        arr.add(new id(R.drawable.sherlock,"SHERLOCK\n",R.drawable.sherlockbg,"Team of 2\n","There are no big problems there are just a lot of little problems\n","Find the hidden clue with programming knowledge\n" +
                "Less time comsumer is the winner.\n" + "Internet should not be accessed.\n",""));
        arr.add(new id(R.drawable.web_design,"Tri-ethalon",R.drawable.web_background,"Team of 2\n","Crafting, visually stunning , Memorable experiences.","Design the poster within the given time\n" +
                "    Web designing templates not allowed. \n" +"  \n","  Round 1: Poster Designing \n" +"  Round 2: Web designing concepts \n" + "  Round 3: Web designing.\n"));
        arr.add(new id(R.drawable.coding_icon,"Coding and Debugging",R.drawable.coding_bg,"Team of 2\n","Deleted code is debugged code. \n","", "Round 1: Debug the snippets within 20 min the maximum number of snippets debugged goes to next round.\n" +
                        "Round 2: Write the program with logic to obtain the specified output.\n"));
        arr.add(new id(R.drawable.connection_icon,"Connexions",R.drawable.connection_icon2,"Team of 2\n","All you have to do its connect \n","", "    Round 1: Google It\n" +
                        "    Round 2: Find the word by connecting the images\n" + "    Round 3: Rearrange the code to obtain the specified output\n"));
        arr.add(new id(R.drawable.javaic,"Coffee with Java",R.drawable.java,"","Do the simplest thing that could possibly work.  \n","",
                "       Round 1: quiz on java\n" +"    Round 2: coding    \n"));
        arr.add(new id(R.drawable.triviaic,"Business Trivia ",R.drawable.trivia,"","Its a corporate challenge. Promote and excel","",
               "     Round 1: slogan writing\n" +  "     Round 2: Tackle the given business situations. \n"));
        arr.add(new id(R.drawable.quiz_icon,"Quiz ",R.drawable.quiz_bg," Individual event","Shout right out.  Be ready be smart be noticed","",
                "    Round 1: quantitative aptitude test.\n" + "Round 2: GK questions Mcq.\n" +"Round 3: Technical queations with choice\n"));
        arr.add(new id(R.drawable.game,"Gaming ",R.drawable.gm,"","Life oa short play moreee. It's not just a game it's an addiction.","", ""));
        arr.add(new id(R.drawable.photoic,"Photography and short film ",R.drawable.photo,"","  See what others cannot see. A virtual world of live pictures. \n" ,"",""));
        arr.add(new id(R.drawable.innovationic,"Minute to Minute ",R.drawable.minute,""," Innovative in the moment\n" , "", " "));
        arr.add(new id(R.drawable.treasurehunt,"Treasure Hunt ",R.drawable.treasuremap,""," The surprise is the prize.\n" , "", " "));
        arr.add(new id(R.drawable.razzmatazzic,"Raazmataaz ",R.drawable.razzmatazz,""," Team work makes the dream work. Two parts game one part obsession.\n" , "", " "));
        arr.add(new id(R.drawable.cricketic,"Box cricket ",R.drawable.cricket,"","Feel the fever of world cup\n" , "", " "));
        arr.add(new id(R.drawable.paper_icon,"Paper presentation  ",R.drawable.paper_bg," Max of 2 members ","   For all you budding enthusiasts out there!  Let your mind quite the paper not the hands. \n" ,
                "Topics: Anything related to Computer Technology.\n" + " Mail us at : melange16papers@gmail.com\n", " "));
        mAdapter = new adap(arr);
        mRecyclerView.setAdapter(mAdapter);
    }
}

