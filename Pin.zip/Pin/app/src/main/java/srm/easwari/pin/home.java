package srm.easwari.pin;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;

public class home extends Fragment {
    private ImageButton mImageView;
    private Animation mAnim;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.welcome, container, false);
        addListenerOnButton(rootView);
        return rootView;
    }
    public void addListenerOnButton(View v) {
        mImageView = (ImageButton) v.findViewById(R.id.icon);

        mAnim = AnimationUtils.loadAnimation(getContext(), R.anim.view_animation);
        mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mImageView.startAnimation(mAnim);
            }
        });
        ImageButton imgbutton = (ImageButton)v.findViewById(R.id.u);
        imgbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), youtube.class);
                startActivity(intent);
            }
        });
        FloatingActionButton fab = (FloatingActionButton) v.findViewById(R.id.mapButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    Intent geoIntent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=EASWARI+ENGINEERING+COLLEGE+Bharathi+Salai+Ramapuram+Chennai+Tamil+Nadu+600089"));
                    startActivity(geoIntent);

                } catch (Exception e) {

                }
            }
        });
    }
}