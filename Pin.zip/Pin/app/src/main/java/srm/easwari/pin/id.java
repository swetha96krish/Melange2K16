package srm.easwari.pin;

/**
 * Created by LENOVO on 2/26/2016.
 */
public class id {
    int imgid,bgid;
    String eve,desc,rounds,members,rules;
    public id(int n,String eve,int bg,String nop,String de,String r,String nor)
    {
        imgid=n;
       this.eve=eve;
        bgid=bg;
        members=nop;
        desc=de;
        rules=r;
        rounds=nor;

    }

    public int getImgid() {
        return imgid;
    }
    public int getBgid() {
        return bgid;
    }
    public String getEve(){ return eve; }
    public String getMembers(){ return members; }
    public String getDesc(){ return desc; }
    public String getRules(){ return rules; }
    public String getRounds(){ return rounds; }
}
