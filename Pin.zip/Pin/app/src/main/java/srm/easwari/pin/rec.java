package srm.easwari.pin;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

/**
 * Created by LENOVO on 2/24/2016.
 */
public class rec extends Fragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.rec, container, false);
        addListenerOnButton(rootView);
        return rootView;
    }
    public void addListenerOnButton(View root){
        mRecyclerView = (RecyclerView) root.findViewById(R.id.rv);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        mRecyclerView.setHasFixedSize(true);

        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(root.getContext());
        mRecyclerView.setLayoutManager(mLayoutManager);

        // specify an adapter (see also next example)
        ArrayList<details> arr=new ArrayList<details>();
                    arr.add(new details("President",R.drawable.cld,"9999999999"));
        arr.add(new details("President",R.drawable.cld,"9999999999"));
        arr.add(new details("President",R.drawable.cld,"9999999999"));

        mAdapter = new MyAdapter(arr);
        mRecyclerView.setAdapter(mAdapter);
    }
}
