    package srm.easwari.pin;

    import android.app.AlertDialog;
    import android.app.ProgressDialog;
    import android.content.Context;
    import android.content.Intent;
    import android.graphics.drawable.ColorDrawable;
    import android.graphics.drawable.PaintDrawable;
    import android.net.Uri;
    import android.os.Bundle;
    import android.support.design.widget.FloatingActionButton;
    import android.support.v4.app.Fragment;
    import android.support.v7.app.AppCompatActivity;
    import android.util.Log;
    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.view.inputmethod.InputMethodManager;
    import android.widget.AdapterView;
    import android.widget.ArrayAdapter;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.Spinner;
    import android.widget.TextView;
    import android.widget.Toast;

    import java.util.ArrayList;
    import java.util.List;

    public class register extends Fragment implements AdapterView.OnItemSelectedListener {
        private final String TAG = "register";
        private ProgressDialog  progress;
        PinnacleUser u = new PinnacleUser();
        int f = 0;
        char d = '.', a = '@';
        private ProgressDialog pDialog;
        private EditText fname, lname, dept, college, phone, mail;
        private Spinner year;
        private Context c;
        private AlertDialog al;
        private Button submit,back;
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.register, container, false);
            c=getContext();
            addButtonListener(rootView);
            return rootView;
        }
        public void addButtonListener(View v){
            Spinner spinner = (Spinner) v.findViewById(R.id.year);

                    submit=(Button)v.findViewById(R.id.submit);
            back=(Button)v.findViewById(R.id.back);
            fname = (EditText) v.findViewById(R.id.fname);
            lname = (EditText) v.findViewById(R.id.lname);
            dept = (EditText) v.findViewById(R.id.dept);
            college = (EditText) v.findViewById(R.id.college);
            year = (Spinner) v.findViewById(R.id.year);
            phone = (EditText) v.findViewById(R.id.phone);
            mail = (EditText) v.findViewById(R.id.mailid);
            submit.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    f = 0;
                    u.fname = fname.getText().toString();
                    nullVerify(u.fname, fname);
                    u.lname = lname.getText().toString();
                    u.dept = dept.getText().toString();
                    nullVerify(u.dept, dept);
                    u.college = college.getText().toString();
                    nullVerify(u.college, college);
                    u.phno = phone.getText().toString();
                    nullVerify(u.phno, phone);
                    phnoVerify();
                    u.mail = mail.getText().toString();
                    nullVerify(u.mail, mail);
                    mailVerify();
                    if (f == 7) {
                        new RegisterClient(c).execute(u);//php class contains the AsyncTask method

                    }
                }
            });
            back.setOnClickListener(new View.OnClickListener() {
                                        public void onClick(View v) {
                                            fname.setText("");
                                            lname.setText("");
                                            dept.setText("");
                                            college.setText("");
                                            phone.setText("");
                                            mail.setText("");
                                            Toast.makeText(getActivity(), "empty", Toast.LENGTH_SHORT).show();

                                        }
                                    }
            );
                // Spinner click listener
            spinner.setOnItemSelectedListener(this);
            List<Integer> categories = new ArrayList<Integer>();
            categories.add(1);
            categories.add(2);
            categories.add(3);
            categories.add(4);
            // Creating adapter for spinner
            ArrayAdapter<Integer> dataAdapter = new ArrayAdapter<Integer>(getActivity(), android.R.layout.simple_spinner_item, categories);
            // Drop down layout style - list view with radio button
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // attaching data adapter to spinner
            spinner.setAdapter(dataAdapter);
        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            // On selecting a spinner item
            u.year  = parent.getItemAtPosition(position).toString();
        }
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }


        public void nullVerify(String s, EditText et) {
            if (s.equals("")) {
                Toast.makeText(getActivity(), "please check for empty field", Toast.LENGTH_SHORT).show();
                et.setBackgroundResource(R.color.error);
                f--;
            } else {
                et.setBackgroundResource(0);
                f++;
            }
            Log.e("reg", "" + f + et);
        }

        public void mailVerify() {
            if ((u.mail.indexOf(a) > 1) && (u.mail.lastIndexOf(d) > 2) && (u.mail.lastIndexOf(d) > u.mail.indexOf(a) + 1)) {
                f++;
            } else {
                Toast.makeText(getActivity(), "invalid mail", Toast.LENGTH_SHORT).show();
                mail.setBackgroundResource(R.color.error);
                f--;
            }
            Log.e("reg", "" + f + mail);
        }

        public void phnoVerify() {
            if ((u.phno.length() == 10) && ((u.phno.charAt(0) == '9') || (u.phno.charAt(0) == '8') || (u.phno.charAt(0) == '7'))) {
               f++;
                }
            else {
                Toast.makeText(getActivity(), "invalid phone number", Toast.LENGTH_SHORT).show();
                phone.setBackgroundResource(R.color.error);
                f--;
            }
            Log.e("reg", "" + f + phone);
        }


    }

