package srm.easwari.pin;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import android.widget.ImageView;
import android.widget.LinearLayout;


public class splash extends AppCompatActivity {

    // Splash screen timer
    private static int SPLASH_TIME_OUT = 10000;
private AnimationDrawable mAnim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.animate);

        final ImageView imageView = (ImageView) findViewById(R.id.ani);

        imageView.setBackgroundResource(R.drawable.snake);

        //mAnim = (AnimationDrawable) imageView.getBackground();
        LinearLayout anil = (LinearLayout) findViewById(R.id.anil);
        anil.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(splash.this, welcome.class);

                startActivity(i);

            }

        });
        new Handler().postDelayed(new Runnable() {

            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start your app main activity
                imageView.setBackgroundResource(R.drawable.logo1);
                Intent i = new Intent(splash.this, welcome.class);
                startActivity(i);

                // close this activity
                finish();
            }
        }, SPLASH_TIME_OUT);
    }

/*
    @Override
    protected void onPause() {
        super.onPause();
        if (mAnim.isRunning()) {
            mAnim.stop();

        }
    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            mAnim.start();
        }
    }*/
}


