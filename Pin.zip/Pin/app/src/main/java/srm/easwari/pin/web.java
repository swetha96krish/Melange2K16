package srm.easwari.pin;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

import java.net.URL;

/**
 * Created by LENOVO on 2/11/2016.
 */
public class web extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web);
        WebView wv=(WebView)findViewById(R.id.webView);
        String u=getIntent().getStringExtra("url");
        wv.loadUrl(u);
    }

}
